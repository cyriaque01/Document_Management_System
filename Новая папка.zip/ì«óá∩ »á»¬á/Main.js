var all_autocomplete_objs = [];

fetch("https://jsonplaceholder.typicode.com/todos")
  .then((response) => response.json())
  .then((res_json) => {
	let title_list = [];
	res_json.forEach((obj) => {
		title_list.push(obj.title)
	}); 
	configure_dropdown("example_input_button", "example_input", title_list)
 });

configure_dropdown = (dropdown_button_id, dropdown_input_id, dropdown_list) =>{
	let awesomecomplete_settings = {
		minChars: 0,
		maxItems: 1000000000,
		filter: Awesomplete.FILTER_STARTSWITH,
		autoFirst: true,
		sort: false
	};
	let dropdown_input = document.getElementById(dropdown_input_id);
	let awesomecomplete_obj = new Awesomplete(dropdown_input, awesomecomplete_settings);
	awesomecomplete_obj.list = dropdown_list;
	all_autocomplete_objs.push(awesomecomplete_obj);

	 document.getElementById(dropdown_button_id).addEventListener("click", () =>{
	 	if (awesomecomplete_obj.ul.childNodes.length ===0) {
	 		awesomecomplete_obj.minChars = 0;
	 		awesomecomplete_obj.evaluate();
	 	} else if (awesomecomplete_obj.ul.hasAttribute('hidden')){
	 		all_autocomplete_objs.forEach((obj) =>{
	 			obj.close()
	 		});
	 		awesomecomplete_obj.open();

	 	} else {
	 		awesomecomplete_obj.close();
	 	}

	 	});
	 };
